package arbre;



public class ArbreBinaire implements ArbreBinaireInterface {

	Sommet racine;
	int nbElements=0; 
	

	public void ajout (int valeur) {
		racine = ajoutRecursive (racine, valeur);
		
		
	}
	
	
	
	
	private Sommet ajoutRecursive(Sommet courrant, int valeur) {
		nbElements++;
		if(courrant == null) {
			return new Sommet(valeur);
		}
		
		if (valeur < courrant.valeur) {
			courrant.gauche = ajoutRecursive(courrant.gauche, valeur);
			
		}
		else if (valeur >courrant.valeur) {
			courrant.droite = ajoutRecursive(courrant.droite, valeur);
		
		}
		return courrant;
	}




	@Override
	public boolean estVide() {
		if(racine==null)
		return true;
		else 
		return false;
	}




	@Override
	public int taille() {
		
		return nbElements;
	}




	@Override
	public boolean contientSommet(int valeur) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public void suppression(int valeur) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void parcoursOrdre(Sommet sommet) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void parcoursPreOrdre(Sommet sommet) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void parcoursPostOrdre(Sommet sommet) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void parcoursLargeur() {
		// TODO Auto-generated method stub
		
	}

}
