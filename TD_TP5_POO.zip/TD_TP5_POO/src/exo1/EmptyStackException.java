package exo1;

public class EmptyStackException extends Exception {

	

	/**
	 * 
	 */
	public EmptyStackException() {

	}

	/**
	 * @param message
	 */
	public EmptyStackException(String message) {
		super(message);
	}

	public String getMessage() {
		return super.getMessage();
	}
}
	
	

