package Tableau;

public interface File {
	public void enfiler(Object ob);
	public Object defiler();
	public Object lireDebut();
	public boolean fileVide();
	public int taille();
	public void afficherFile(); 
}
