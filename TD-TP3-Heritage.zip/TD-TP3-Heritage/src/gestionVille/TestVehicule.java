package gestionVille;

public class TestVehicule {

	public static void main(String[] args) {
		Vehicule v1 = new Vehicule();
		System.out.println(v1.getInfo());
	}

}
