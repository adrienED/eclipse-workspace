package gestionVille;

public class Ville {

	public Ville() {
		// TODO Auto-generated constructor stub
	}

}
